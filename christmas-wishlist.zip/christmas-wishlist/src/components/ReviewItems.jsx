import { useState, useEffect } from 'react';
import { items, children, authStore } from '../lib/pocketbase';

export default function ReviewItems() {
  const [allItems, setAllItems] = useState([]);
  const [childrenList, setChildrenList] = useState([]);
  const [filter, setFilter] = useState('pending'); // pending, approved, rejected, all
  const [loading, setLoading] = useState(true);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectingItem, setRejectingItem] = useState(null);
  const [rejectionReason, setRejectionReason] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userId = authStore.user()?.id;
      const childrenData = await children.list(userId);
      setChildrenList(childrenData);

      const allItemsList = await items.list();
      setAllItems(allItemsList);
    } catch (err) {
      console.error('Error loading data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (itemId) => {
    try {
      await items.approve(itemId);
      loadData();
    } catch (err) {
      console.error('Error approving item:', err);
      alert('Failed to approve item.');
    }
  };

  const handleReject = async () => {
    if (!rejectingItem) return;

    try {
      await items.reject(rejectingItem.id, rejectionReason);
      setShowRejectModal(false);
      setRejectingItem(null);
      setRejectionReason('');
      loadData();
    } catch (err) {
      console.error('Error rejecting item:', err);
      alert('Failed to reject item.');
    }
  };

  const handleDelete = async (itemId) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      try {
        await items.delete(itemId);
        loadData();
      } catch (err) {
        console.error('Error deleting item:', err);
        alert('Failed to delete item.');
      }
    }
  };

  const openRejectModal = (item) => {
    setRejectingItem(item);
    setRejectionReason('');
    setShowRejectModal(true);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  const filteredItems = allItems.filter(item => {
    if (filter === 'all') return true;
    return item.status === filter;
  });

  const getChildName = (childId) => {
    const child = childrenList.find(c => c.id === childId);
    return child?.name || 'Unknown';
  };

  const pendingCount = allItems.filter(item => item.status === 'pending').length;
  const approvedCount = allItems.filter(item => item.status === 'approved').length;
  const rejectedCount = allItems.filter(item => item.status === 'rejected').length;

  return (
    <>
      <div style={{ marginBottom: '30px' }}>
        <h2 style={{ marginBottom: '10px' }}>Review Items</h2>
        <p style={{ color: '#718096', marginBottom: '20px' }}>
          Review and approve items from your children's wishlists. Approved items will be visible to family members.
        </p>

        <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
          <button
            onClick={() => setFilter('pending')}
            className={`btn ${filter === 'pending' ? 'btn-primary' : 'btn-secondary'}`}
          >
            Pending ({pendingCount})
          </button>
          <button
            onClick={() => setFilter('approved')}
            className={`btn ${filter === 'approved' ? 'btn-primary' : 'btn-secondary'}`}
          >
            Approved ({approvedCount})
          </button>
          <button
            onClick={() => setFilter('rejected')}
            className={`btn ${filter === 'rejected' ? 'btn-primary' : 'btn-secondary'}`}
          >
            Rejected ({rejectedCount})
          </button>
          <button
            onClick={() => setFilter('all')}
            className={`btn ${filter === 'all' ? 'btn-primary' : 'btn-secondary'}`}
          >
            All ({allItems.length})
          </button>
        </div>
      </div>

      {filteredItems.length === 0 ? (
        <div className="empty-state">
          <h2>No items found</h2>
          <p>
            {filter === 'pending' && 'No items waiting for review.'}
            {filter === 'approved' && 'No approved items yet.'}
            {filter === 'rejected' && 'No rejected items.'}
            {filter === 'all' && 'No items have been added yet.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-2">
          {filteredItems.map(item => (
            <div key={item.id} className="item-card">
              {item.image_url && (
                <img src={item.image_url} alt={item.title} />
              )}
              
              <div style={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: '10px', 
                marginBottom: '8px' 
              }}>
                <h3 style={{ flex: 1 }}>{item.title}</h3>
                <span className={`badge badge-${item.status}`}>
                  {item.status}
                </span>
              </div>

              <div style={{ 
                fontSize: '14px', 
                color: '#667eea', 
                fontWeight: 600,
                marginBottom: '8px'
              }}>
                {getChildName(item.child)}
              </div>

              {item.description && <p>{item.description}</p>}
              
              <div className="price">${item.price.toFixed(2)}</div>

              {item.url && (
                <a 
                  href={item.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  style={{ 
                    color: '#667eea', 
                    textDecoration: 'none',
                    display: 'block',
                    marginBottom: '12px'
                  }}
                >
                  View Product →
                </a>
              )}

              {item.status === 'rejected' && item.rejection_reason && (
                <div style={{
                  background: '#fee2e2',
                  padding: '8px 12px',
                  borderRadius: '6px',
                  fontSize: '14px',
                  color: '#991b1b',
                  marginBottom: '12px'
                }}>
                  <strong>Reason:</strong> {item.rejection_reason}
                </div>
              )}

              {item.expand?.reservations_via_item?.length > 0 && (
                <div style={{
                  background: '#dbeafe',
                  padding: '8px 12px',
                  borderRadius: '6px',
                  fontSize: '14px',
                  color: '#1e40af',
                  marginBottom: '12px'
                }}>
                  <strong>Reserved by:</strong>{' '}
                  {item.expand.reservations_via_item[0].expand?.reserved_by?.name || 'Family member'}
                </div>
              )}

              <div className="item-actions">
                {item.status === 'pending' && (
                  <>
                    <button
                      onClick={() => handleApprove(item.id)}
                      className="btn btn-success"
                    >
                      Approve
                    </button>
                    <button
                      onClick={() => openRejectModal(item)}
                      className="btn btn-danger"
                    >
                      Reject
                    </button>
                  </>
                )}
                {item.status === 'rejected' && (
                  <button
                    onClick={() => handleApprove(item.id)}
                    className="btn btn-success"
                  >
                    Approve
                  </button>
                )}
                {item.status === 'approved' && !item.expand?.reservations_via_item?.length && (
                  <button
                    onClick={() => openRejectModal(item)}
                    className="btn btn-danger"
                  >
                    Unapprove
                  </button>
                )}
                <button
                  onClick={() => handleDelete(item.id)}
                  className="btn btn-secondary"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showRejectModal && (
        <div className="modal-overlay" onClick={() => setShowRejectModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h2>Reject Item</h2>
            <p style={{ color: '#718096', marginBottom: '20px' }}>
              Provide a reason for rejecting "{rejectingItem?.title}".
              This will be visible to your child.
            </p>
            
            <div className="input-group">
              <label>Reason</label>
              <textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="e.g., Too expensive, not age-appropriate, etc."
                rows={4}
              />
            </div>

            <div className="modal-actions">
              <button
                onClick={() => setShowRejectModal(false)}
                className="btn btn-secondary"
              >
                Cancel
              </button>
              <button
                onClick={handleReject}
                className="btn btn-danger"
              >
                Reject Item
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
