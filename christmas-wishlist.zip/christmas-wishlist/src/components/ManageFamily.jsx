import { useState, useEffect } from 'react';
import pb from '../lib/pocketbase';

export default function ManageFamily() {
  const [familyMembers, setFamilyMembers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFamilyMembers();
  }, []);

  const loadFamilyMembers = async () => {
    try {
      const members = await pb.collection('users').getFullList({
        filter: 'role = "family_member"',
        sort: 'created',
      });
      setFamilyMembers(members);
    } catch (err) {
      console.error('Error loading family members:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = async (memberId) => {
    if (window.confirm('Are you sure you want to remove this family member? They will lose access to the wishlist.')) {
      try {
        await pb.collection('users').delete(memberId);
        loadFamilyMembers();
      } catch (err) {
        console.error('Error removing family member:', err);
        alert('Failed to remove family member.');
      }
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <>
      <div style={{ marginBottom: '30px' }}>
        <h2 style={{ marginBottom: '10px' }}>Family Members</h2>
        <p style={{ color: '#718096', marginBottom: '20px' }}>
          View and manage family members who have access to the approved wishlist items.
          Family members can sign up at <strong>/signup</strong>.
        </p>
      </div>

      {familyMembers.length === 0 ? (
        <div className="empty-state">
          <h2>No family members yet</h2>
          <p>Share the signup link with family members so they can create accounts and view the wishlist.</p>
        </div>
      ) : (
        <>
          <div className="stats-grid" style={{ gridTemplateColumns: '1fr' }}>
            <div className="stat-card">
              <h3>Total Family Members</h3>
              <div className="value">{familyMembers.length}</div>
            </div>
          </div>

          <div className="grid grid-2">
            {familyMembers.map(member => {
              const joinDate = new Date(member.created);
              const formattedDate = joinDate.toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric'
              });

              return (
                <div key={member.id} className="card">
                  <div style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    alignItems: 'start',
                    marginBottom: '16px'
                  }}>
                    <div style={{ flex: 1 }}>
                      <h3 style={{ fontSize: '20px', marginBottom: '8px' }}>
                        {member.name}
                      </h3>
                      <p style={{ color: '#718096', fontSize: '14px', marginBottom: '4px' }}>
                        {member.email}
                      </p>
                      <p style={{ color: '#718096', fontSize: '14px' }}>
                        Joined: {formattedDate}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleRemove(member.id)}
                    className="btn btn-danger"
                    style={{ width: '100%' }}
                  >
                    Remove Access
                  </button>
                </div>
              );
            })}
          </div>
        </>
      )}
    </>
  );
}
