import { useState, useEffect } from 'react';
import pb, { children, authStore } from '../lib/pocketbase';

export default function ManageChildren() {
  const [childrenList, setChildrenList] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingChild, setEditingChild] = useState(null);
  const [loading, setLoading] = useState(true);
  
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    pin: '',
    target_budget: '',
  });

  useEffect(() => {
    loadChildren();
  }, []);

  const loadChildren = async () => {
    try {
      const userId = authStore.user()?.id;
      const list = await children.list(userId);
      setChildrenList(list);
    } catch (err) {
      console.error('Error loading children:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const childData = {
        name: formData.name,
        age: formData.age ? parseInt(formData.age) : null,
        pin: formData.pin,
        target_budget: formData.target_budget ? parseFloat(formData.target_budget) : null,
        parent: authStore.user()?.id,
      };

      if (editingChild) {
        await children.update(editingChild.id, childData);
      } else {
        await children.create(childData);
      }

      setShowModal(false);
      setEditingChild(null);
      setFormData({
        name: '',
        age: '',
        pin: '',
        target_budget: '',
      });
      loadChildren();
    } catch (err) {
      console.error('Error saving child:', err);
      alert('Failed to save child. Please try again.');
    }
  };

  const handleEdit = (child) => {
    setEditingChild(child);
    setFormData({
      name: child.name,
      age: child.age?.toString() || '',
      pin: child.pin,
      target_budget: child.target_budget?.toString() || '',
    });
    setShowModal(true);
  };

  const handleDelete = async (childId) => {
    if (window.confirm('Are you sure? This will delete the child and all their wishlist items.')) {
      try {
        await children.delete(childId);
        loadChildren();
      } catch (err) {
        console.error('Error deleting child:', err);
        alert('Failed to delete child.');
      }
    }
  };

  const generateRandomPin = () => {
    const pin = Math.floor(1000 + Math.random() * 9000).toString();
    setFormData({ ...formData, pin });
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <>
      <div style={{ marginBottom: '30px' }}>
        <h2 style={{ marginBottom: '10px' }}>Manage Children</h2>
        <p style={{ color: '#718096', marginBottom: '20px' }}>
          Add your children and set up their login credentials. They'll use their Child ID and PIN to access their wishlist.
        </p>
        <button
          onClick={() => {
            setEditingChild(null);
            setFormData({
              name: '',
              age: '',
              pin: '',
              target_budget: '',
            });
            setShowModal(true);
          }}
          className="btn btn-primary"
        >
          + Add Child
        </button>
      </div>

      {childrenList.length === 0 ? (
        <div className="empty-state">
          <h2>No children added yet</h2>
          <p>Add your children to get started with their wishlists.</p>
        </div>
      ) : (
        <div className="grid grid-2">
          {childrenList.map(child => (
            <div key={child.id} className="card">
              <div style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'start',
                marginBottom: '16px'
              }}>
                <div>
                  <h3 style={{ fontSize: '24px', marginBottom: '8px' }}>
                    {child.name}
                  </h3>
                  {child.age && (
                    <p style={{ color: '#718096' }}>Age: {child.age}</p>
                  )}
                </div>
              </div>

              <div style={{ 
                background: '#f7fafc', 
                padding: '16px', 
                borderRadius: '8px',
                marginBottom: '16px'
              }}>
                <div style={{ marginBottom: '12px' }}>
                  <strong style={{ color: '#4a5568' }}>Child ID:</strong>
                  <div style={{ 
                    fontFamily: 'monospace', 
                    fontSize: '18px',
                    marginTop: '4px',
                    color: '#667eea'
                  }}>
                    {child.id}
                  </div>
                </div>
                <div>
                  <strong style={{ color: '#4a5568' }}>PIN:</strong>
                  <div style={{ 
                    fontFamily: 'monospace', 
                    fontSize: '18px',
                    marginTop: '4px',
                    color: '#667eea'
                  }}>
                    {child.pin}
                  </div>
                </div>
              </div>

              {child.target_budget && (
                <div style={{ marginBottom: '16px' }}>
                  <strong style={{ color: '#4a5568' }}>Target Budget:</strong>
                  <div style={{ fontSize: '20px', color: '#667eea', marginTop: '4px' }}>
                    ${child.target_budget.toFixed(2)}
                  </div>
                </div>
              )}

              <div className="item-actions">
                <button
                  onClick={() => handleEdit(child)}
                  className="btn btn-primary"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(child.id)}
                  className="btn btn-danger"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h2>{editingChild ? 'Edit Child' : 'Add New Child'}</h2>
            
            <form onSubmit={handleSubmit}>
              <div className="input-group">
                <label>Name *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  placeholder="Child's name"
                />
              </div>

              <div className="input-group">
                <label>Age</label>
                <input
                  type="number"
                  min="0"
                  max="18"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                  placeholder="Optional"
                />
              </div>

              <div className="input-group">
                <label>PIN *</label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <input
                    type="text"
                    value={formData.pin}
                    onChange={(e) => setFormData({ ...formData, pin: e.target.value })}
                    required
                    placeholder="4-digit PIN"
                    style={{ flex: 1 }}
                  />
                  <button
                    type="button"
                    onClick={generateRandomPin}
                    className="btn btn-secondary"
                  >
                    Generate
                  </button>
                </div>
                <small style={{ color: '#718096', marginTop: '4px', display: 'block' }}>
                  The child will use this PIN to log in
                </small>
              </div>

              <div className="input-group">
                <label>Target Budget (Optional)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.target_budget}
                  onChange={(e) => setFormData({ ...formData, target_budget: e.target.value })}
                  placeholder="e.g., 300.00"
                />
                <small style={{ color: '#718096', marginTop: '4px', display: 'block' }}>
                  Used for equity tracking
                </small>
              </div>

              <div className="modal-actions">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="btn btn-secondary"
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  {editingChild ? 'Update' : 'Add'} Child
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
