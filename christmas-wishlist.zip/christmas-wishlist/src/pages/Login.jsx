import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth } from '../lib/pocketbase';

export default function Login() {
  const navigate = useNavigate();
  const [userType, setUserType] = useState('parent'); // parent, child, family_member
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [childId, setChildId] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (userType === 'parent') {
        await auth.loginParent(email, password);
        navigate('/parent');
      } else if (userType === 'child') {
        await auth.loginChild(childId, pin);
        navigate('/child');
      } else if (userType === 'family_member') {
        await auth.loginFamily(email, password);
        navigate('/family');
      }
    } catch (err) {
      setError(err.message || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ 
      minHeight: '100vh', 
      display: 'flex', 
      alignItems: 'center', 
      justifyContent: 'center',
      padding: '20px'
    }}>
      <div className="card" style={{ maxWidth: '500px', width: '100%' }}>
        <h1 style={{ 
          textAlign: 'center', 
          color: '#667eea', 
          marginBottom: '30px',
          fontSize: '32px'
        }}>
          🎄 Christmas Wishlist
        </h1>

        <div style={{ 
          display: 'flex', 
          gap: '10px', 
          marginBottom: '30px',
          borderRadius: '8px',
          background: '#f7fafc',
          padding: '4px'
        }}>
          <button
            className={`btn ${userType === 'parent' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setUserType('parent')}
            style={{ flex: 1 }}
          >
            Parent
          </button>
          <button
            className={`btn ${userType === 'child' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setUserType('child')}
            style={{ flex: 1 }}
          >
            Child
          </button>
          <button
            className={`btn ${userType === 'family_member' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setUserType('family_member')}
            style={{ flex: 1 }}
          >
            Family
          </button>
        </div>

        {error && <div className="error-message">{error}</div>}

        <form onSubmit={handleSubmit}>
          {(userType === 'parent' || userType === 'family_member') && (
            <>
              <div className="input-group">
                <label>Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="your@email.com"
                />
              </div>

              <div className="input-group">
                <label>Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  placeholder="••••••••"
                />
              </div>
            </>
          )}

          {userType === 'child' && (
            <>
              <div className="input-group">
                <label>Child ID</label>
                <input
                  type="text"
                  value={childId}
                  onChange={(e) => setChildId(e.target.value)}
                  required
                  placeholder="Ask your parent for this"
                />
              </div>

              <div className="input-group">
                <label>PIN</label>
                <input
                  type="password"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  required
                  placeholder="Your PIN"
                />
              </div>
            </>
          )}

          <button 
            type="submit" 
            className="btn btn-primary" 
            style={{ width: '100%', marginTop: '20px' }}
            disabled={loading}
          >
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </form>

        {userType === 'family_member' && (
          <div style={{ textAlign: 'center', marginTop: '20px' }}>
            <p style={{ color: '#718096' }}>
              Don't have an account?{' '}
              <a 
                href="/signup" 
                style={{ color: '#667eea', fontWeight: 600 }}
              >
                Sign up here
              </a>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
