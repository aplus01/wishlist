import { useState, useEffect } from 'react';
import { auth, items as itemsAPI, reservations as reservationsAPI } from '../lib/pocketbase';

export default function FamilyView() {
  const [approvedItems, setApprovedItems] = useState([]);
  const [myReservations, setMyReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all'); // all, available, reserved

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const allApprovedItems = await itemsAPI.listApproved();
      setApprovedItems(allApprovedItems);

      const userId = auth.authStore.user()?.id;
      const myRes = await reservationsAPI.list({ reserved_by: userId });
      setMyReservations(myRes);
    } catch (err) {
      console.error('Error loading data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleReserve = async (itemId) => {
    try {
      await reservationsAPI.create(itemId);
      loadData();
    } catch (err) {
      console.error('Error reserving item:', err);
      alert('Failed to reserve item. It may already be reserved.');
    }
  };

  const handleUnreserve = async (reservationId) => {
    if (window.confirm('Are you sure you want to unreserve this item?')) {
      try {
        await reservationsAPI.delete(reservationId);
        loadData();
      } catch (err) {
        console.error('Error unreserving item:', err);
        alert('Failed to unreserve item.');
      }
    }
  };

  const handleMarkPurchased = async (reservationId) => {
    try {
      await reservationsAPI.markPurchased(reservationId);
      loadData();
    } catch (err) {
      console.error('Error marking as purchased:', err);
      alert('Failed to mark as purchased.');
    }
  };

  const handleLogout = () => {
    auth.logout();
    window.location.href = '/login';
  };

  if (loading) {
    return <div className="container">Loading...</div>;
  }

  const isItemReserved = (item) => {
    return item.expand?.reservations_via_item?.length > 0;
  };

  const getMyReservation = (item) => {
    const userId = auth.authStore.user()?.id;
    return item.expand?.reservations_via_item?.find(res => res.reserved_by === userId);
  };

  const filteredItems = approvedItems.filter(item => {
    if (filter === 'available') return !isItemReserved(item);
    if (filter === 'reserved') return getMyReservation(item);
    return true;
  });

  // Group items by child
  const itemsByChild = filteredItems.reduce((acc, item) => {
    const childName = item.expand?.child?.name || 'Unknown';
    if (!acc[childName]) acc[childName] = [];
    acc[childName].push(item);
    return acc;
  }, {});

  return (
    <>
      <div className="header">
        <div className="header-content">
          <h1>🎄 Family Gift List</h1>
          <button onClick={handleLogout} className="btn btn-secondary">
            Logout
          </button>
        </div>
      </div>

      <div className="container">
        <div className="card" style={{ marginBottom: '30px' }}>
          <h2 style={{ marginBottom: '16px' }}>Welcome, {auth.authStore.user()?.name}!</h2>
          <p style={{ color: '#718096', marginBottom: '20px' }}>
            Browse the approved wishlist items and reserve gifts you'd like to purchase.
            Once reserved, no one else can claim that item!
          </p>

          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <button
              onClick={() => setFilter('all')}
              className={`btn ${filter === 'all' ? 'btn-primary' : 'btn-secondary'}`}
            >
              All Items ({approvedItems.length})
            </button>
            <button
              onClick={() => setFilter('available')}
              className={`btn ${filter === 'available' ? 'btn-primary' : 'btn-secondary'}`}
            >
              Available ({approvedItems.filter(item => !isItemReserved(item)).length})
            </button>
            <button
              onClick={() => setFilter('reserved')}
              className={`btn ${filter === 'reserved' ? 'btn-primary' : 'btn-secondary'}`}
            >
              My Reservations ({myReservations.length})
            </button>
          </div>
        </div>

        {filteredItems.length === 0 ? (
          <div className="empty-state">
            <h2>No items found</h2>
            <p>
              {filter === 'available' && 'All items have been reserved!'}
              {filter === 'reserved' && "You haven't reserved any items yet."}
              {filter === 'all' && 'No approved items available yet.'}
            </p>
          </div>
        ) : (
          Object.entries(itemsByChild).map(([childName, childItems]) => (
            <div key={childName} style={{ marginBottom: '40px' }}>
              <h2 style={{ 
                marginBottom: '20px', 
                color: '#667eea',
                borderBottom: '2px solid #667eea',
                paddingBottom: '8px'
              }}>
                {childName}'s Wishlist
              </h2>

              <div className="grid grid-3">
                {childItems.map(item => {
                  const reserved = isItemReserved(item);
                  const myReservation = getMyReservation(item);

                  return (
                    <div key={item.id} className="item-card">
                      {item.image_url && (
                        <img src={item.image_url} alt={item.title} />
                      )}
                      
                      <div style={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        gap: '10px', 
                        marginBottom: '8px' 
                      }}>
                        <h3 style={{ flex: 1 }}>{item.title}</h3>
                        {reserved && (
                          <span className="badge badge-reserved">
                            {myReservation ? 'Reserved by You' : 'Reserved'}
                          </span>
                        )}
                      </div>

                      {item.description && <p>{item.description}</p>}
                      
                      <div className="price">${item.price.toFixed(2)}</div>

                      {item.url && (
                        <a 
                          href={item.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          style={{ 
                            color: '#667eea', 
                            textDecoration: 'none',
                            display: 'block',
                            marginBottom: '12px'
                          }}
                        >
                          View Product →
                        </a>
                      )}

                      <div className="item-actions">
                        {!reserved && (
                          <button
                            onClick={() => handleReserve(item.id)}
                            className="btn btn-success"
                            style={{ width: '100%' }}
                          >
                            Reserve This Gift
                          </button>
                        )}

                        {myReservation && (
                          <>
                            {!myReservation.purchased && (
                              <>
                                <button
                                  onClick={() => handleMarkPurchased(myReservation.id)}
                                  className="btn btn-primary"
                                >
                                  Mark Purchased
                                </button>
                                <button
                                  onClick={() => handleUnreserve(myReservation.id)}
                                  className="btn btn-secondary"
                                >
                                  Unreserve
                                </button>
                              </>
                            )}
                            {myReservation.purchased && (
                              <div style={{
                                background: '#d1fae5',
                                padding: '8px',
                                borderRadius: '6px',
                                textAlign: 'center',
                                color: '#065f46',
                                fontWeight: 600
                              }}>
                                ✓ Purchased
                              </div>
                            )}
                          </>
                        )}

                        {reserved && !myReservation && (
                          <div style={{
                            background: '#e2e8f0',
                            padding: '8px',
                            borderRadius: '6px',
                            textAlign: 'center',
                            color: '#4a5568',
                            fontWeight: 600
                          }}>
                            Reserved by Another Family Member
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))
        )}
      </div>
    </>
  );
}
