import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import pb, { authStore } from './lib/pocketbase';

// Import pages
import Login from './pages/Login';
import ParentDashboard from './pages/ParentDashboard';
import ChildWishlist from './pages/ChildWishlist';
import FamilyView from './pages/FamilyView';
import FamilySignup from './pages/FamilySignup';

function App() {
  const [user, setUser] = useState(authStore.user());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is already logged in
    setUser(authStore.user());
    setLoading(false);

    // Listen for auth changes
    const unsubscribe = pb.authStore.onChange(() => {
      setUser(authStore.user());
    });

    return unsubscribe;
  }, []);

  if (loading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh',
        fontFamily: 'system-ui, -apple-system, sans-serif'
      }}>
        <div>Loading...</div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={!user ? <Login /> : <Navigate to="/" />} />
        <Route path="/signup" element={<FamilySignup />} />
        
        {/* Parent Routes */}
        <Route 
          path="/parent/*" 
          element={user?.role === 'parent' ? <ParentDashboard /> : <Navigate to="/login" />} 
        />
        
        {/* Child Routes */}
        <Route 
          path="/child" 
          element={user?.role === 'child' ? <ChildWishlist /> : <Navigate to="/login" />} 
        />
        
        {/* Family Member Routes */}
        <Route 
          path="/family" 
          element={user?.role === 'family_member' ? <FamilyView /> : <Navigate to="/login" />} 
        />
        
        {/* Default redirect based on role */}
        <Route 
          path="/" 
          element={
            !user ? <Navigate to="/login" /> :
            user.role === 'parent' ? <Navigate to="/parent" /> :
            user.role === 'child' ? <Navigate to="/child" /> :
            user.role === 'family_member' ? <Navigate to="/family" /> :
            <Navigate to="/login" />
          } 
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
